# PrizmCore - heart of PRIZM project.

## This is [Android Application](http://tech.prizm-space.com/prizm.apk)

## User friendly [Online Wallet (http)](http://wallet.prizm-space.com/) / [Online Wallet (https)](https://wallet.prizm.space/)

## Special (only for professionals) [Technical Wallet](http://tech.prizm-space.com/)

## Fully functional (NEW VERSION) [PrizmCore build with technical interface](http://tech.prizm.space/prizm-dist.tgz)

## Easy API gateway [PrizmAPIServlet](http://tech.prizm.space/prizmAPI.tgz)

## Windows installer (NEW VERSION) [PrizmSetup-1.9.15.exe](http://tech.prizm.space/PrizmSetup-1.9.15.exe)

## Blockchain explorer [BlockChain.PRIZM.SPACE](http://blockchain.prizm.space/)

Attention! We don't include PrizmEngine.java in current repository for security reasons and for preventing creating forks by anyone. This file will be published later.
